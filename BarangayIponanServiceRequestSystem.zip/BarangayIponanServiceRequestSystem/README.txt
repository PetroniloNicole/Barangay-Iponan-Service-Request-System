BARANGAY IPONAN SERVICE REQUEST SYSTEM
======================================

TITLE SUGGESTION:
Barangay Iponan Service Request and Management System

FEATURES
--------
USER:
- Register an account
- Log in and log out
- Submit a service request
- View only their own requests
- Refresh the request list

ADMIN:
- Log in using the seeded admin account
- View all users' service requests
- Edit service details and status
- Delete a selected request
- Process requests using Pending, Processing, Completed, or Rejected

PROJECT STRUCTURE
-----------------
src/
  Main.java
  model/
    User.java
    ServiceRequest.java
  service/
    DatabaseConnection.java
    UserService.java
    RequestService.java
  gui/
    LoginFrame.java
    RegisterFrame.java
    DashboardFrame.java
database.sql

REQUIREMENTS
------------
1. JDK 17 or newer recommended.
2. MySQL Server (MySQL Workbench is optional).
3. MySQL Connector/J JDBC driver.

DATABASE SETUP
--------------
1. Open MySQL Workbench or the MySQL command line.
2. Run the entire database.sql script.
3. Open src/service/DatabaseConnection.java.
4. Set USER and PASSWORD to your local MySQL account credentials.
5. Add MySQL Connector/J to the project's libraries/classpath.

RUN IN NETBEANS
---------------
1. Create a Java project.
2. Create the package folders: model, service, gui.
3. Copy each .java file into the matching package.
4. Add MySQL Connector/J to project Libraries.
5. Run Main.java.

RUN FROM A TERMINAL
-------------------
If you compile manually, place the MySQL Connector/J jar at a known path and
replace MYSQL_CONNECTOR_JAR with that path.

Windows example:
  javac -cp ".;MYSQL_CONNECTOR_JAR" -d out src\Main.java src\model\*.java src\service\*.java src\gui\*.java
  java -cp "out;MYSQL_CONNECTOR_JAR" Main

On macOS/Linux, use colon (:) instead of semicolon in the classpath.

DEMO ADMIN LOGIN
----------------
Username: admin
Password: admin123

Register normal user accounts through the Register button on the login window.

IMPORTANT NOTES
---------------
- This is a college project prototype, not a production-ready public service.
- Records are stored in MySQL and remain after the app closes.
- The sample uses SHA-256 for simple demonstration. SHA-256 alone is not recommended
  for production password storage; use BCrypt or Argon2 in a real deployment.
- The admin password is a demo credential. Change it before any real use.
- Do not use real residents' private information for classroom testing.
- For a real deployment, add stronger password hashing, role/permission checks,
  input validation, backups, audit logs, and applicable privacy safeguards.
