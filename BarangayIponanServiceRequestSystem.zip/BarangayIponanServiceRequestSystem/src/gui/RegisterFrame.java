package gui;

import service.UserService;
import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class RegisterFrame extends JFrame {
    private final UserService userService = new UserService();
    private final JTextField fullNameField = new JTextField(18);
    private final JTextField usernameField = new JTextField(18);
    private final JPasswordField passwordField = new JPasswordField(18);
    private final JPasswordField confirmField = new JPasswordField(18);

    public RegisterFrame() {
        setTitle("Create User Account");
        setSize(420, 360);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(22, 22, 22, 22));
        panel.add(new JLabel("Full name:"));
        panel.add(fullNameField);
        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(new JLabel("Confirm password:"));
        panel.add(confirmField);

        JButton registerButton = new JButton("Register");
        JButton cancelButton = new JButton("Cancel");
        panel.add(registerButton);
        panel.add(cancelButton);
        add(panel);

        registerButton.addActionListener(e -> register());
        cancelButton.addActionListener(e -> dispose());
    }

    private void register() {
        String fullName = fullNameField.getText().trim();
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String confirm = new String(confirmField.getPassword());

        if (fullName.isEmpty() || username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all required fields.");
            return;
        }
        if (password.length() < 6) {
            JOptionPane.showMessageDialog(this, "Use a password with at least 6 characters.");
            return;
        }
        if (!password.equals(confirm)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match.");
            return;
        }

        try {
            boolean success = userService.register(fullName, username, password);
            if (success) {
                JOptionPane.showMessageDialog(this, "Account created. You can now log in.");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "That username is already taken.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Could not register account.\n" + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
