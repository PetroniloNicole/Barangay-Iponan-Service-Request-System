package gui;

import model.User;
import service.UserService;
import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class LoginFrame extends JFrame {
    private final UserService userService = new UserService();
    private final JTextField usernameField = new JTextField(18);
    private final JPasswordField passwordField = new JPasswordField(18);

    public LoginFrame() {
        setTitle("Barangay Iponan Service Request System - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(460, 360);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));
        root.setBackground(new Color(242, 247, 252));

        JLabel title = new JLabel("BARANGAY IPONAN", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 23));
        title.setForeground(new Color(25, 65, 112));

        JLabel subtitle = new JLabel("Service Request System", SwingConstants.CENTER);
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 15));

        JPanel heading = new JPanel(new GridLayout(2, 1, 0, 5));
        heading.setOpaque(false);
        heading.add(title);
        heading.add(subtitle);

        JPanel form = new JPanel(new GridLayout(4, 1, 6, 6));
        form.setOpaque(false);
        form.add(new JLabel("Username"));
        form.add(usernameField);
        form.add(new JLabel("Password"));
        form.add(passwordField);

        JButton loginButton = new JButton("Log In");
        loginButton.setBackground(new Color(35, 112, 190));
        loginButton.setForeground(Color.WHITE);
        JButton registerButton = new JButton("Create User Account");

        JPanel buttons = new JPanel(new GridLayout(2, 1, 0, 8));
        buttons.setOpaque(false);
        buttons.add(loginButton);
        buttons.add(registerButton);

        root.add(heading, BorderLayout.NORTH);
        root.add(form, BorderLayout.CENTER);
        root.add(buttons, BorderLayout.SOUTH);
        add(root);

        loginButton.addActionListener(e -> login());
        passwordField.addActionListener(e -> login());
        registerButton.addActionListener(e -> new RegisterFrame().setVisible(true));
    }

    private void login() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter your username and password.");
            return;
        }

        try {
            User user = userService.login(username, password);
            if (user == null) {
                JOptionPane.showMessageDialog(this, "Invalid username or password.");
                return;
            }
            dispose();
            new DashboardFrame(user).setVisible(true);
        } catch (SQLException ex) {
            showDatabaseError(ex);
        }
    }

    private void showDatabaseError(Exception ex) {
        JOptionPane.showMessageDialog(this,
                "Could not connect to the database.\n"
                + "Check MySQL, the database settings, and Connector/J.\n\n"
                + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
    }
}
