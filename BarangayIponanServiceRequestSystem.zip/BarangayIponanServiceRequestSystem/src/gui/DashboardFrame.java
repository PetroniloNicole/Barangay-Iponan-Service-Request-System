package gui;

import model.ServiceRequest;
import model.User;
import service.RequestService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class DashboardFrame extends JFrame {
    private final User user;
    private final RequestService requestService = new RequestService();
    private final DefaultTableModel tableModel = new DefaultTableModel(
            new String[]{"ID", "Resident", "Service", "Purpose", "Contact",
                         "Notes", "Status", "Date"}, 0) {
        @Override public boolean isCellEditable(int row, int col) { return false; }
    };
    private final JTable table = new JTable(tableModel);
    private final JTextField serviceField = new JTextField(18);
    private final JTextField purposeField = new JTextField(18);
    private final JTextField contactField = new JTextField(18);
    private final JTextField notesField = new JTextField(18);
    private final JComboBox<String> statusBox = new JComboBox<>(
            new String[]{"Pending", "Processing", "Completed", "Rejected"});
    private final JLabel welcomeLabel;

    public DashboardFrame(User user) {
        this.user = user;
        setTitle("Barangay Iponan Service Request System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 650);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8, 8));

        welcomeLabel = new JLabel("Welcome, " + user.getFullName()
                + "  |  Role: " + user.getRole());
        welcomeLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(14, 14, 8, 14));
        add(welcomeLabel, BorderLayout.NORTH);

        JPanel form = buildForm();
        add(form, BorderLayout.WEST);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        JScrollPane scrollPane = new JScrollPane(table);

        JPanel tablePanel = new JPanel(new BorderLayout(5, 5));
        tablePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 10));
        JButton refreshButton = new JButton("Refresh");
        JButton logoutButton = new JButton("Log Out");
        JPanel topButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        topButtons.add(refreshButton);
        topButtons.add(logoutButton);
        tablePanel.add(topButtons, BorderLayout.NORTH);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        add(tablePanel, BorderLayout.CENTER);

        refreshButton.addActionListener(e -> loadRequests());
        logoutButton.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                loadSelectedRow();
            }
        });

        loadRequests();
    }

    private JPanel buildForm() {
        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));
        panel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEmptyBorder(8, 12, 8, 12),
                user.getRole().equals("ADMIN") ? "Manage Request" : "New Service Request"));
        panel.setPreferredSize(new Dimension(285, 0));

        panel.add(new JLabel("Service type:"));
        panel.add(serviceField);
        panel.add(new JLabel("Purpose:"));
        panel.add(purposeField);
        panel.add(new JLabel("Contact number:"));
        panel.add(contactField);
        panel.add(new JLabel("Notes:"));
        panel.add(notesField);

        boolean admin = user.getRole().equals("ADMIN");
        panel.add(new JLabel("Request status:"));
        panel.add(statusBox);
        statusBox.setEnabled(admin);

        JButton saveButton = new JButton(admin ? "Save Changes" : "Submit Request");
        JButton deleteButton = new JButton("Delete Selected");
        JButton clearButton = new JButton("Clear Form");
        panel.add(saveButton);
        panel.add(deleteButton);
        panel.add(clearButton);

        if (admin) {
            saveButton.addActionListener(e -> updateSelectedRequest());
            deleteButton.addActionListener(e -> deleteSelectedRequest());
        } else {
            saveButton.addActionListener(e -> createRequest());
            deleteButton.setVisible(false);
        }
        clearButton.addActionListener(e -> clearForm());

        JLabel hint = new JLabel("<html><small>"
                + (admin ? "Select a row to edit status/details."
                         : "You can view only your own requests.")
                + "</small></html>");
        panel.add(hint);
        return panel;
    }

    private void createRequest() {
        if (serviceField.getText().trim().isEmpty()
                || purposeField.getText().trim().isEmpty()
                || contactField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter service type, purpose, and contact number.");
            return;
        }
        try {
            requestService.createRequest(user, serviceField.getText().trim(),
                    purposeField.getText().trim(), contactField.getText().trim(),
                    notesField.getText().trim());
            JOptionPane.showMessageDialog(this, "Service request submitted!");
            clearForm();
            loadRequests();
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void loadRequests() {
        try {
            List<ServiceRequest> requests = user.getRole().equals("ADMIN")
                    ? requestService.getAllRequests()
                    : requestService.getRequestsForUser(user.getId());

            tableModel.setRowCount(0);
            for (ServiceRequest r : requests) {
                tableModel.addRow(new Object[]{
                    r.getId(), r.getResidentName(), r.getServiceType(),
                    r.getPurpose(), r.getContactNumber(), r.getNotes(),
                    r.getStatus(), r.getCreatedAt()
                });
            }
            int[] widths = {45, 150, 140, 180, 115, 150, 90, 160};
            for (int i = 0; i < widths.length; i++) {
                table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
            }
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void loadSelectedRow() {
        int row = table.getSelectedRow();
        serviceField.setText(valueAt(row, 2));
        purposeField.setText(valueAt(row, 3));
        contactField.setText(valueAt(row, 4));
        notesField.setText(valueAt(row, 5));
        statusBox.setSelectedItem(valueAt(row, 6));
    }

    private String valueAt(int row, int column) {
        Object value = tableModel.getValueAt(row, column);
        return value == null ? "" : value.toString();
    }

    private void updateSelectedRequest() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a request from the table first.");
            return;
        }
        if (serviceField.getText().trim().isEmpty()
                || purposeField.getText().trim().isEmpty()
                || contactField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Service, purpose, and contact are required.");
            return;
        }
        try {
            int id = Integer.parseInt(valueAt(row, 0));
            requestService.updateRequest(id, serviceField.getText().trim(),
                    purposeField.getText().trim(), contactField.getText().trim(),
                    notesField.getText().trim(), statusBox.getSelectedItem().toString());
            JOptionPane.showMessageDialog(this, "Request updated.");
            clearForm();
            loadRequests();
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void deleteSelectedRequest() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a request to delete.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete the selected request?", "Confirm",
                JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try {
            int id = Integer.parseInt(valueAt(row, 0));
            requestService.deleteRequest(id);
            clearForm();
            loadRequests();
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void clearForm() {
        serviceField.setText("");
        purposeField.setText("");
        contactField.setText("");
        notesField.setText("");
        statusBox.setSelectedItem("Pending");
        table.clearSelection();
    }

    private void showError(Exception ex) {
        JOptionPane.showMessageDialog(this,
                "Database operation failed:\n" + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }
}
