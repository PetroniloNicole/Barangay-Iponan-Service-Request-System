package service;

import model.User;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;

public class UserService {

    // Demo-level password hashing. For a production system, use BCrypt or Argon2.
    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder();
            for (byte b : bytes) {
                result.append(String.format("%02x", b));
            }
            return result.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Password hashing is unavailable.", e);
        }
    }

    public boolean register(String fullName, String username, String password)
            throws SQLException {
        String sql = "INSERT INTO users (full_name, username, password_hash, role) "
                   + "VALUES (?, ?, ?, 'USER')";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, fullName.trim());
            ps.setString(2, username.trim());
            ps.setString(3, hashPassword(password));
            ps.executeUpdate();
            return true;
        } catch (SQLIntegrityConstraintViolationException e) {
            return false; // Username already exists
        }
    }

    public User login(String username, String password) throws SQLException {
        String sql = "SELECT id, full_name, username, role FROM users "
                   + "WHERE username = ? AND password_hash = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username.trim());
            ps.setString(2, hashPassword(password));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new User(rs.getInt("id"), rs.getString("full_name"),
                            rs.getString("username"), rs.getString("role"));
                }
            }
        }
        return null;
    }
}
