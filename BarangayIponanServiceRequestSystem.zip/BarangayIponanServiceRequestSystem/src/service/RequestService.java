package service;

import model.ServiceRequest;
import model.User;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RequestService {

    public boolean createRequest(User user, String serviceType, String purpose,
            String contactNumber, String notes) throws SQLException {
        String sql = "INSERT INTO service_requests "
                + "(user_id, resident_name, service_type, purpose, contact_number, notes) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, user.getId());
            ps.setString(2, user.getFullName());
            ps.setString(3, serviceType);
            ps.setString(4, purpose);
            ps.setString(5, contactNumber);
            ps.setString(6, notes);
            return ps.executeUpdate() == 1;
        }
    }

    public List<ServiceRequest> getRequestsForUser(int userId) throws SQLException {
        String sql = "SELECT * FROM service_requests WHERE user_id = ? ORDER BY created_at DESC";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                return readRequests(rs);
            }
        }
    }

    public List<ServiceRequest> getAllRequests() throws SQLException {
        String sql = "SELECT * FROM service_requests ORDER BY created_at DESC";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return readRequests(rs);
        }
    }

    public boolean updateRequest(int id, String serviceType, String purpose,
            String contactNumber, String notes, String status) throws SQLException {
        String sql = "UPDATE service_requests SET service_type=?, purpose=?, "
                + "contact_number=?, notes=?, status=? WHERE id=?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, serviceType);
            ps.setString(2, purpose);
            ps.setString(3, contactNumber);
            ps.setString(4, notes);
            ps.setString(5, status);
            ps.setInt(6, id);
            return ps.executeUpdate() == 1;
        }
    }

    public boolean deleteRequest(int id) throws SQLException {
        String sql = "DELETE FROM service_requests WHERE id=?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        }
    }

    private List<ServiceRequest> readRequests(ResultSet rs) throws SQLException {
        List<ServiceRequest> list = new ArrayList<>();
        while (rs.next()) {
            list.add(new ServiceRequest(
                    rs.getInt("id"),
                    rs.getInt("user_id"),
                    rs.getString("resident_name"),
                    rs.getString("service_type"),
                    rs.getString("purpose"),
                    rs.getString("contact_number"),
                    rs.getString("notes"),
                    rs.getString("status"),
                    rs.getTimestamp("created_at")
            ));
        }
        return list;
    }
}
