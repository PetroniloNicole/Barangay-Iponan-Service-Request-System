package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // Update these values to match your local MySQL setup.
    private static final String URL =
            "jdbc:mysql://localhost:3306/barangay_iponan?serverTimezone=Asia/Manila";
    private static final String USER = "root";
    private static final String PASSWORD = ""; // Your MySQL password

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
