package model;

import java.sql.Timestamp;

public class ServiceRequest {
    private int id;
    private int userId;
    private String residentName;
    private String serviceType;
    private String purpose;
    private String contactNumber;
    private String notes;
    private String status;
    private Timestamp createdAt;

    public ServiceRequest(int id, int userId, String residentName,
            String serviceType, String purpose, String contactNumber,
            String notes, String status, Timestamp createdAt) {
        this.id = id;
        this.userId = userId;
        this.residentName = residentName;
        this.serviceType = serviceType;
        this.purpose = purpose;
        this.contactNumber = contactNumber;
        this.notes = notes;
        this.status = status;
        this.createdAt = createdAt;
    }

    public int getId() { return id; }
    public int getUserId() { return userId; }
    public String getResidentName() { return residentName; }
    public String getServiceType() { return serviceType; }
    public String getPurpose() { return purpose; }
    public String getContactNumber() { return contactNumber; }
    public String getNotes() { return notes; }
    public String getStatus() { return status; }
    public Timestamp getCreatedAt() { return createdAt; }
}
