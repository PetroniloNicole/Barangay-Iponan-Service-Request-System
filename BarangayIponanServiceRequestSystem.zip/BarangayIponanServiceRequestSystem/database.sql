CREATE DATABASE IF NOT EXISTS barangay_iponan
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE barangay_iponan;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash CHAR(64) NOT NULL,
    role ENUM('USER', 'ADMIN') NOT NULL DEFAULT 'USER',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS service_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    resident_name VARCHAR(120) NOT NULL,
    service_type VARCHAR(100) NOT NULL,
    purpose VARCHAR(255) NOT NULL,
    contact_number VARCHAR(30) NOT NULL,
    notes TEXT,
    status ENUM('Pending', 'Processing', 'Completed', 'Rejected')
        NOT NULL DEFAULT 'Pending',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_request_user FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE
);

-- Demo administrator:
-- Username: admin
-- Password: admin123
-- The hash below is SHA-256, matching the Java demo code.
INSERT INTO users (full_name, username, password_hash, role)
VALUES ('Barangay Administrator', 'admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'ADMIN')
ON DUPLICATE KEY UPDATE username = VALUES(username);
